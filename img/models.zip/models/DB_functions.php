<?php
include_once 'connection.php';

/**
* 
*/
class DB_Functions
{
	private $DBConnect = null;
	private $db = null;
	function __construct()
	{		
		$this->DBConnect = new DB_Connect();
		$this->db = $this->DBConnect->connect();
	}
	public function insertItem($tablename, $filename)
	{
		$query = "INSERT INTO mamase.$tablename(filename) VALUES('$filename')";
		$result = pg_query($this->db, $query);		
	}
	public function deleteItems($tablename)
	{
		$query = "DELETE FROM mamase.$tablename";
		$result = pg_query($this->db, $query);
	}
	public function getRainfallData()
	{
		//Dekadal data
		$query = "SELECT filename from mamase.dekads";
		$result = pg_query($this->db, $query);
		$dekads = array();
		while ($row = pg_fetch_row($result)) {
		    array_push($dekads, $row[0]);
		}
		//Daily data
		$query = "SELECT filename from mamase.daily";
		$result = pg_query($this->db, $query);
		$daily = array();
		while ($row = pg_fetch_row($result)) {
		    array_push($daily, $row[0]);
		}
		//Prediction data
		$query = "SELECT filename from mamase.predict";
		$result = pg_query($this->db, $query);
		$predicts = array();
		while ($row = pg_fetch_row($result)) {
		    array_push($predicts, $row[0]);
		}
		$data = [$dekads, $daily, $predicts];
		return $data;
	}
	public function getModisData(){
        //MODIS Data
		$host = "130.89.221.193";
		$port = 5432;
		$dbname = "maris_db";
		$user = "postgres";
		$password = "admin$";
		$credentials = 'host=' . $host . ' port=' . $port . ' dbname=' . $dbname . ' user=' . $user . ' password=' . $password;
		$db = pg_connect($credentials);
        $query = "SELECT filename from mamase.ndvi_modis";
        $result = pg_query($db, $query);
        $modis = array();
        while ($row = pg_fetch_row($result)) {
            array_push($modis, $row[0]);
        }
        return $modis;
    }
    public function getMSGdata(){
        //MSG
        $query = "SELECT filename from mamase.ndvi_msg";
        $result = pg_query($this->db, $query);
        $msg = array();
        while ($row = pg_fetch_row($result)) {
            array_push($msg, $row[0]);
        }
        return $msg;
    }
	public function getNDVIdata()
	{
		/*//MODIS Data
		$query = "SELECT filename from mamase.ndvi_modis";
		$result = pg_query($this->db, $query);
		$modis = array();
		while ($row = pg_fetch_row($result)) {
		    array_push($modis, $row[0]);
		}
		//MSG
		$query = "SELECT filename from mamase.ndvi_msg";
		$result = pg_query($this->db, $query);
		$msg = array();
		while ($row = pg_fetch_row($result)) {
		    array_push($msg, $row[0]);
		}*/
		$data = [$this->getModisData(), $this->getMSGdata()];
		return $data;
	}
	public function getModelsData(){
		//Rainfall Data
		$query = "SELECT filename from mamase.rainfall";
		$result = pg_query($this->db, $query);
		$rainfall = array();
		while ($row = pg_fetch_row($result)) {
		    array_push($rainfall, $row[0]);
		}
		//Biomass
		$query = "SELECT filename from mamase.biomass";
		$result = pg_query($this->db, $query);
		$biomass = array();
		$count = 0;
		while ($row = pg_fetch_row($result)) {
		    $count++;
		    array_push($biomass, $row[0]);
		    if($count == count($rainfall)){
		        break;
            }
		}
        $ndvi = $this->getModisData();
		//array_slice($this->getModisData(), 0, count($rainfall));
        //$array1 = array_slice($this->getModisData(), 0, count($rainfall));
        //echo count($ndvi).' '.count($rainfall).' '.count($biomass);
		$data = [array_slice($rainfall,0,count($ndvi)/2), array_slice($biomass,0, count($ndvi)/2), array_slice($ndvi, 0, count($ndvi)/2)];
		return $data;
	}
	public function getSummary(){
		$query = "SELECT a.id, a.date_from,a.date_to, a.conservancy,b.cattlenum,b.sheepnum,b.dmlivestock_days,b.dmwildlife_days,a.totaldm AS total_production,b.dm_total AS total_demand,(CAST(a.totaldm AS INT)-CAST(b.dm_total AS INT)) AS difference, a.days   FROM mamase.dm_production a, mamase.dm_demand_wet b WHERE a.conservancy=b.conservancy";
		$res = pg_query($this->db, $query);
		$summary = array();
		while($row=pg_fetch_assoc($res)){
			$summary[] = $row;
		}
		return json_encode($summary);
	}
}
?>