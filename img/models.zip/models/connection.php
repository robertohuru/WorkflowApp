<?php

class DB_Connect {

    // constructor
    function __construct() {
        
    }

    // destructor
    function __destruct() {
        // $this->close();
    }

    // Connecting to database
    public function connect() {
        require_once 'config.php';
        $host = DB_HOST;
        $port=DB_PORT;
        $dbname = DB_DATABASE;
        $user = DB_USER;
        $password = DB_PASSWORD;
        $credentials = 'host='.$host.' port='.$port.' dbname='.$dbname.' user='.$user.' password='.$password;
        $db = pg_connect('host=localhost port=5432 dbname=maris_db user=postgres password=admin$');
		
		pg_connect($credentials);
        
        return $db;
    }

    // Closing database connection
    public function close() {        
        //mysql_close();
        pg_close();
    }

}