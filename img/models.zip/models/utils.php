<?php
require_once 'C:\Apache24\htdocs\MARIS\utils\models\config.php';
require_once 'C:\Apache24\htdocs\MARIS\utils\models\DB_functions.php';

class FTP {    
	 // constructor
    function __construct() {
    	
    }

    // destructor
    function __destruct() {
    }
    function ftp_file_exists(
    	$file, // the file that you looking for
    	$path,   // the remote folder where it is
    	$ftp_server = "ftp.chg.ucsb.edu", //Server to connect to
      	$ftp_user = "anonymous", //Server username
      	$ftp_pwd = "rohuru@yahoo.com", //Server password
      	$useCache = 1
 		){
    	static $cache_ftp_nlist = array();
      	static $cache_signature = '';

      	$new_signature = "$ftp_server/$path";


      	if(!$useCache || $new_signature!=$cache_signature){
      		//echo $new_signature;
            $useCache = 0;
            //$new_signature = $cache_signature;
             $cache_signature = $new_signature;
            // setup the connection
            $conn_id = ftp_connect($ftp_server) or die("Error connecting $ftp_server");
            $ftp_login = ftp_login($conn_id, $ftp_user, $ftp_pwd);
            ftp_pasv($conn_id, true);
            $cache_ftp_nlist = ftp_nlist($conn_id, $path);
            if ($cache_ftp_nlist===FALSE)die("erro no ftp_nlist");
       }
       $check_file_exist = "$path/$file";
       if(in_array($check_file_exist, $cache_ftp_nlist)){
       		return true;
        } 
        else{
            return false;  
        }
        // use for debuging: var_dump($cache_ftp_nlist);
        if(!$useCache) ftp_close($conn_id);
    }
    function url_Exists($url=NULL)  
    {  
        if($url == NULL) return false;  
        $ch = curl_init($url);  
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);  
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);  
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);  
        $data = curl_exec($ch);  
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);  
        curl_close($ch);  
        if($httpcode>=200 && $httpcode<300){  
            return true;  
        } else {  
            return false;  
        }  
    }
    function urlExists($url) {
        $login = 'mamase';
        $password = 'Masai_Mara1';
        $handle = curl_init($url);
        curl_setopt($handle, CURLOPT_URL,$url);
        curl_setopt($handle, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($handle, CURLOPT_RETURNTRANSFER,1);
        curl_setopt($handle, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
        //curl_setopt($handle, CURLOPT_HTTPHEADER, [ "Authorization: Basic ".base64_encode("$login:$password"), ]);
        curl_setopt($handle, CURLOPT_USERPWD, "$login:$password");        
        $result = curl_exec($handle);  
        $httpCode = curl_getinfo($handle, CURLINFO_HTTP_CODE);
        curl_close($handle);
        if($httpCode == 200 && $httpCode < 400) {
            return 1;
        } else {
            return 0;
        }
    }
    function UR_exists($url){
       $headers=get_headers($url);
       return stripos($headers[0],"200 OK")?1:0;
    }
    
}
class GeoServer{
    private $configFilePath = '';
    //Path to the Jar file
    private $jarFilePath = JAVA_DIR.DIRECTORY_SEPARATOR.'GeoJava.jar'; 
     // constructor
    function __construct() {
        //Path to configuration file config.json
        //Replace forward slash with backward slash
        $this->config = ROOT_DIRECTORY.DIRECTORY_SEPARATOR."config.json";
        $this->configFilePath = str_replace("/",DIRECTORY_SEPARATOR,$this->config);
    }

    // destructor
    function __destruct() {
    }
    /*
    *Function publishes raster maps from a user folder to the geoserver
    *workspace - The name of the worspace where you want to publish the data
    *style - the style of the maps
    *datafolderPath - The path to the local data folder
    *deleteWorspace - 'Yes' or 'No'. Yes to replace the content of the workspace with the new data. No otherwise
    */
    public function publishRasterMaps($workspace, $style, $dataFolderPath, $deleteWorkSpace){       
        $projection = "EPSG:21036";
        $command = 'java -jar '.$this->jarFilePath.' '.$workspace.' '.$dataFolderPath.' '.$style.' '.$projection.' '.$this->configFilePath.' '.$deleteWorkSpace;
        try {
            exec($command);
        }catch (Exception $e) {
                
        }
    }
    /**
    Function uploads the specified styles to the geoserver
    **/
    function uploadStyles(){

    }
}

/**
* This class contains functions that updates the database
*/
class DB_Models
{
    private $DB_Functions = null;
    
    function __construct()
    {
       $this->DB_Functions = new DB_Functions();
    }
    // destructor
    function __destruct() {
    }
    /**
    *Insert the name of the maps into the corresponding table
    */
    public function updateTable($table, $dataFolderPath)
    {
        $this->DB_Functions->deleteItems($table);        
        $files = glob($dataFolderPath.'\*'); //get all file names
        foreach($files as $file){
            if(is_file($file)){
                $ext = pathinfo($file, PATHINFO_EXTENSION);
                if($ext == "tif"){
                    $name = basename($file,".tif");
                    $this->DB_Functions->insertItem($table,$name);
                }
            }
        }
    }
}
/**
* MARIS
*/
class MARIS
{     
    private $working_dir = "";
    private $gdalBinDirectory = "";
    private $mamaseUtilDirectory = "";
    private $ilwisDirectory = "";
    private $outputDirectory = "";
    private $logfh = null;
    private $GeoServer = null;
    private $DB_Models = null;
    function __construct()
    {
        $this->ilwisDirectory = ILWIS_DIR;
        $this->mamaseUtilDirectory = ILWIS_DIR.' '.MAMASE_UTIL;
        $this->gdalBinDirectory = GDAL_UTIL;
        $this->working_dir = WORKING_DISK.DIRECTORY_SEPARATOR."working_dir";
        $this->outputDirectory = WORKING_DISK." working_dir";

        //$this->working_dir = "G:".DIRECTORY_SEPARATOR."working_dir";
        //$this->outputDirectory = "G:"." working_dir";
        $this->logfh = fopen(ROOT_DIRECTORY."\utils\models\Test.txt", 'w') or die("can't open log file");
        $this->GeoServer = new GeoServer();
        $this->DB_Models = new DB_Models();
    }
    // destructor
    function __destruct() {
        # code...
    }
    public function resampleRainfall()
    {
        # code...
    }
    public function generate16DaysRainfallMaps($startDate, $endDate)
    {
        $startYear = $startDate->format('Y');
        $endYear = $endDate->format('Y');
        for($year = $startYear; $year < $endYear; $year++){
            $data = array();
            $p = 0;
            $datetime = new DateTime($year.'-01-01');
            for($i = 1; $i <=353; $i++){
                date_add($datetime,date_interval_create_from_date_string("1 days"));
                $datetime = date_format($datetime,"Y-m-d");
                $datetime = date_create_from_format("Y-m-d", $datetime);
                $date = $datetime->format('Y').$datetime->format('m').$datetime->format('d');
                array_push($data, $date);
                if($i %16 == 0){
                    $p++;
                    $dekads = array();
                    $pentads = array();
                    $dailies = array();
                    if($year %4 == 0){
                        if ($p == 1){
                            $dailies = array($data[0], $data[1], $data[2], $data[3], $data[14], $data[15]);
                            $pentads = array($year.'01'.'2', $year.'01'.'3');
                            $dekads = array();
                        }else if($p == 2){
                            $dailies = array($data[0], $data[1], $data[2], $data[14], $data[15]);
                            $pentads = array();
                            $dekads = array($year.'013');
                        }else if($p == 3){
                            $dailies = array($data[0], $data[1], $data[2], $data[3], $data[13], $data[14], $data[15]);
                            $pentads = array($year.'02'.'2', $year.'02'.'3');
                            $dekads = array();
                        }else if($p == 4){
                            $dailies = array($data[0], $data[1]);
                            $pentads = array($year.'03'.'1');
                            $dekads = array($year.'023');
                        }else if($p == 5){
                            $dailies = array($data[15]);
                            $pentads = array($year.'03'.'2');
                            $dekads = array($year.'032');
                        }else if($p == 6){
                            $dailies = array($data[0], $data[1], $data[2], $data[3], $data[15]);
                            $pentads = array($year.'03'.'6', $year.'04'.'1');
                            $dekads = array();
                        }else if($p == 7){
                            $dailies = array($data[0], $data[1], $data[2], $data[3], $data[14], $data[15]);
                            $pentads = array();
                            $dekads = array($year.'042');
                        }else if($p == 8){
                            $dailies = array($data[0], $data[1], $data[2], $data[13], $data[14], $data[15]);
                            $pentads = array($year.'04'.'6', $year.'05'.'1');
                            $dekads = array();
                        }else if($p == 9){
                            $dailies = array($data[0], $data[1], $data[12], $data[13], $data[14], $data[15]);
                            $pentads = array();
                            $dekads = array($year.'052');
                        }else if($p == 10){
                            $dailies = array($data[0], $data[12], $data[13], $data[14], $data[15]);
                            $pentads = array($year.'05'.'6', $year.'06'.'1');
                            $dekads = array();
                        }else if($p == 11){
                            $dailies = array($data[0]);
                            $pentads = array($year.'06'.'5');
                            $dekads = array($year.'062');
                        }else if($p == 12){
                            $dailies = array($data[15]);
                            $pentads = array($year.'06'.'6');
                            $dekads = array($year.'071');
                        }else if($p == 13){
                            $dailies = array($data[0], $data[1], $data[2], $data[3], $data[14], $data[15]);
                            $pentads = array($year.'07'.'4', $year.'07'.'5');
                            $dekads = array();
                        }else if($p == 14){
                            $dailies = array($data[0], $data[1], $data[2], $data[3], $data[14], $data[15]);
                            $pentads = array();
                            $dekads = array($year.'081');
                        }else if($p == 15){
                            $dailies = array($data[0], $data[1], $data[2], $data[13], $data[14], $data[15]);
                            $pentads = array($year.'08'.'4', $year.'08'.'5');
                            $dekads = array();
                        }else if($p == 16){
                            $dailies = array($data[0], $data[1], $data[2], $data[13], $data[14], $data[15]);
                            $pentads = array();
                            $dekads = array($year.'091');
                        }else if($p == 17){
                            $dailies = array($data[0], $data[1], $data[12], $data[13], $data[14], $data[15]);
                            $pentads = array($year.'09'.'4', $year.'09'.'5');
                            $dekads = array();
                        }else if($p == 18){
                            $dailies = array($data[0]);
                            $pentads = array($year.'10'.'3');
                            $dekads = array($year.'101');
                        }else if($p == 19){
                            $dailies = array();
                            $pentads = array($year.'10'.'4');
                            $dekads = array($year.'103');
                        }else if($p == 20){
                            $dailies = array($data[15]);
                            $pentads = array($year.'11'.'3');
                            $dekads = array($year.'111');
                        }else if($p == 21){
                            $dailies = array($data[0], $data[1], $data[2], $data[3], $data[14], $data[15]);
                            $pentads = array();
                            $dekads = array($year.'113');
                        }else if($p == 22){
                            $dailies = array($data[0], $data[1], $data[2], $data[13], $data[14], $data[15]);
                            $pentads = array($year.'12'.'2', $year.'12'.'3');
                            $dekads = array();
                        }
                    }else{
                        if ($p == 1){
                            $dailies = array($data[0], $data[1], $data[2], $data[3], $data[14], $data[15]);
                            $pentads = array($year.'01'.'2', $year.'01'.'3');
                            $dekads = array();
                        }else if($p == 2){
                            $dailies = array($data[0], $data[1], $data[2], $data[14], $data[15]);
                            $pentads = array();
                            $dekads = array($year.'013');
                        }else if($p == 3){
                            $dailies = array($data[0], $data[1], $data[2], $data[3], $data[13], $data[14], $data[15]);
                            $pentads = array($year.'02'.'2', $year.'02'.'3');
                            $dekads = array();
                        }else if($p == 4){
                            $dailies = array($data[0], $data[1], $data[15]);
                            $pentads = array($year.'03'.'1');
                            $dekads = array($year.'023');
                        }else if($p == 5){
                            $dailies = array($data[0],$data[1],$data[2],$data[3],$data[14],$data[15]);
                            $pentads = array();
                            $dekads = array($year.'032');
                        }else if($p == 6){
                            $dailies = array($data[0], $data[1], $data[2], $data[14], $data[15]);
                            $pentads = array($year.'03'.'6', $year.'04'.'1');
                            $dekads = array();
                        }else if($p == 7){
                            $dailies = array($data[0], $data[1], $data[2], $data[13], $data[14], $data[15]);
                            $pentads = array();
                            $dekads = array($year.'042');
                        }else if($p == 8){
                            $dailies = array($data[0], $data[1], $data[12], $data[13], $data[14], $data[15]);
                            $pentads = array($year.'04'.'6', $year.'05'.'1');
                            $dekads = array();
                        }else if($p == 9){
                            $dailies = array($data[0]);
                            $pentads = array($year.'05'.'5');
                            $dekads = array($year.'052');
                        }else if($p == 10){
                            $dailies = array();
                            $pentads = array($year.'05'.'6');
                            $dekads = array($year.'061');
                        }else if($p == 11){
                            $dailies = array($data[15]);
                            $pentads = array($year.'06'.'5');
                            $dekads = array($year.'062');
                        }else if($p == 12){
                            $dailies = array($data[0], $data[1], $data[2], $data[3], $data[14], $data[15]);
                            $pentads = array();
                            $dekads = array($year.'071');
                        }else if($p == 13){
                            $dailies = array($data[0], $data[1], $data[2], $data[13], $data[14], $data[15]);
                            $pentads = array($year.'07'.'4', $year.'07'.'5');
                            $dekads = array();
                        }else if($p == 14){
                            $dailies = array($data[0], $data[1], $data[2], $data[13], $data[14], $data[15]);
                            $pentads = array();
                            $dekads = array($year.'081');
                        }else if($p == 15){
                            $dailies = array($data[0], $data[1], $data[12], $data[13], $data[14], $data[15]);
                            $pentads = array($year.'08'.'4', $year.'08'.'5');
                            $dekads = array();
                        }else if($p == 16){
                            $dailies = array($data[0], $data[1], $data[12], $data[13], $data[14], $data[15]);
                            $pentads = array();
                            $dekads = array($year.'091');
                        }else if($p == 17){
                            $dailies = array($data[0]);
                            $pentads = array($year.'09'.'4');
                            $dekads = array($year.'093');
                        }else if($p == 18){
                            $dailies = array($data[15]);
                            $pentads = array($year.'10'.'3');
                            $dekads = array($year.'101');
                        }else if($p == 19){
                            $dailies = array($data[0],$data[1],$data[2],$data[3],$data[15]);
                            $pentads = array();
                            $dekads = array($year.'103');
                        }else if($p == 20){
                            $dailies = array($data[0],$data[1],$data[2],$data[3],$data[14],$data[15]);
                            $pentads = array($year.'11'.'2',$year.'11'.'3');
                            $dekads = array();
                        }else if($p == 21){
                            $dailies = array($data[0], $data[1], $data[2], $data[13], $data[14], $data[15]);
                            $pentads = array();
                            $dekads = array($year.'113');
                        }else if($p == 22){
                            $dailies = array($data[0], $data[1], $data[12], $data[13], $data[14], $data[15]);
                            $pentads = array($year.'12'.'2', $year.'12'.'3');
                            $dekads = array();
                        }
                    }
                    $directory = $this->working_dir.DIRECTORY_SEPARATOR."Model_data".DIRECTORY_SEPARATOR."Rainfall_data";
                    if(!file_exists($directory)){
                        mkdir($directory);
                    }
                    $file = "chirps-v2.0.".$datetime->format('Y').'.'.$datetime->format('m').'.'.$datetime->format('d').".tif"; //the file you are looking for
                    $path = "pub/org/chg/products/CHIRPS-2.0/africa_daily/tifs/p25/".$year; //the path where the file is located
                    $ftpClass = new FTP();
                    if(!file_exists($directory.DIRECTORY_SEPARATOR."rainfall_map_".$data[15].".tif") && ($ftpClass->ftp_file_exists($file, $path) == true || $ftpClass->ftp_file_exists($file.'.gz', $path) == true))
                    {
                        $mapList = array();
                        foreach ($dailies as $daily) {
                            $batch_file_path = BATCH_DIR.DIRECTORY_SEPARATOR.'Chirps_Day_MAMASE.bat ';
                            $command = ILWIS_DIR.DIRECTORY_SEPARATOR."ilwis.exe -C !".$batch_file_path.$daily." x  x  ".$this->outputDirectory.DIRECTORY_SEPARATOR."Model_data".DIRECTORY_SEPARATOR."Rainfall_data".' ' .$this->gdalBinDirectory.' ' .$this->mamaseUtilDirectory;
                            $file_name = "chirps_daily_".$daily.".mpr";
                            if(!file_exists($directory.DIRECTORY_SEPARATOR.$file_name)){
                                try {
                                    exec($command);
                                } catch (Exception $e) {}
                            }
                            if(file_exists($directory.DIRECTORY_SEPARATOR.$file_name)){
                                array_push($mapList, $directory.DIRECTORY_SEPARATOR.$file_name);
                            }
                        }
                        foreach ($pentads as $pentad) {
                            $batch_file_path = BATCH_DIR.DIRECTORY_SEPARATOR.'Chirps_PENTAD_MAMASE.bat ';
                            $command = ILWIS_DIR.DIRECTORY_SEPARATOR."ilwis.exe -C !".$batch_file_path.$pentad." x  x  ".$this->outputDirectory.DIRECTORY_SEPARATOR."Model_data".DIRECTORY_SEPARATOR."Rainfall_data".' ' .$this->gdalBinDirectory.' ' .$this->mamaseUtilDirectory;
                            $file_name = "chirps_pentad_".$pentad.".mpr";
                            if(!file_exists($directory.DIRECTORY_SEPARATOR.$file_name)){
                                try {
                                    exec($command);
                                } catch (Exception $e) {}
                            }
                            if(file_exists($directory.DIRECTORY_SEPARATOR.$file_name)){
                                array_push($mapList, $directory.DIRECTORY_SEPARATOR.$file_name);
                            }
                        }
                        foreach ($dekads as $dekad) {
                            $batch_file_path = BATCH_DIR.DIRECTORY_SEPARATOR.'Chirps_DEKAD_MAMASE.bat ';
                            $command = ILWIS_DIR.DIRECTORY_SEPARATOR."ilwis.exe -C !".$batch_file_path.$dekad." x  x  ".$this->outputDirectory.DIRECTORY_SEPARATOR."Model_data".DIRECTORY_SEPARATOR."Rainfall_data".' ' .$this->gdalBinDirectory.' ' .$this->mamaseUtilDirectory;
                            $file_name = "chirps_dekad_".$dekad.".mpr";
                            if(!file_exists($directory.DIRECTORY_SEPARATOR.$file_name)){
                                try {
                                    exec($command);
                                } catch (Exception $e) {}
                            }
                            if(file_exists($directory.DIRECTORY_SEPARATOR.$file_name)){
                                array_push($mapList, $directory.DIRECTORY_SEPARATOR.$file_name);
                            }
                        }
                        $list = '"'.implode(" ",$mapList).'"';
                        $batch_file_path = BATCH_DIR.DIRECTORY_SEPARATOR.'Chirps16Days_Aggregate.bat ';
                        $command = ILWIS_DIR.DIRECTORY_SEPARATOR."ilwis.exe -C !".$batch_file_path.$list." ".$this->outputDirectory.DIRECTORY_SEPARATOR."Model_data".DIRECTORY_SEPARATOR."Rainfall_data".' '.ILWIS_DIR.' ' .$this->gdalBinDirectory.' ' .$data[15];
                        try {
                            exec($command);
                        } catch (Exception $e) {}
                        fwrite($this->logfh, $list."\n");
                        $mapList = array();
                        $dailies = array();
                        $pentads = array();
                        $dekads = array();
                    }
                    $data = array();
                }                
            }
        }
        $this->getRainfallOne($startDate, $endDate);
        $style = "rainfall16Days_style";
        $workspace = 'Model_Rainfall';
        $dataFolderPath = $directory;
        $this->GeoServer->publishRasterMaps($workspace, $style, $dataFolderPath, 'Yes');
        /**
         *Insert the name of the rainfall maps to the database
         */
        $this->DB_Models->updateTable("rainfall", $dataFolderPath);


    }
    public function getRainfallOne($startDate, $endDate){
        $startYear = $startDate->format('Y');
        $startYear = $startYear-1;
        $endYear = $endDate->format('Y');
        $endYear = $endYear-1;
        $startDate = new DateTime($startYear.'-12-19');
        for($year = $startYear; $year < $endYear; $year++){
            $data = array();
            $days = 16;
            if($year %4 == 0){
                $startDate = new DateTime($year.'-12-19');
                $days = 14;
            }else{
                $startDate = new DateTime($year.'-12-20');
                $days = 13;
            }
            for($day =0; $day < $days ; $day++){
                array_push($data, $startDate->format('Y').$startDate->format('m').$startDate->format('d'));
                date_add($startDate,date_interval_create_from_date_string("1 days"));
                $startDate = date_format($startDate,"Y-m-d");
                $startDate = date_create_from_format("Y-m-d", $startDate);
            }
            $x = $days-1;
            $dekads = array();
            $dailies = array();
            $pentads = array();
            if($days == 14){
                $dailies = array($data[0],$data[1],$data[$x]);
                $pentads = array();
                $dekads = array($year.'123');
            }  else{
                $dailies = array($data[0],$data[$x]);
                $pentads = array();
                $dekads = array($year.'123');
            }
            $directory = $this->working_dir.DIRECTORY_SEPARATOR."Model_data".DIRECTORY_SEPARATOR."Rainfall_data";
            if(!file_exists($directory.DIRECTORY_SEPARATOR."rainfall_map_".$data[$x].".tif"))
            {
                $mapList = array();
                foreach ($dailies as $daily) {
                    $batch_file_path = BATCH_DIR.DIRECTORY_SEPARATOR.'Chirps_Day_MAMASE.bat ';
                    $command = ILWIS_DIR.DIRECTORY_SEPARATOR."ilwis.exe -C !".$batch_file_path.$daily." x  x  ".$this->outputDirectory.DIRECTORY_SEPARATOR."Model_data".DIRECTORY_SEPARATOR."Rainfall_data".' ' .$this->gdalBinDirectory.' ' .$this->mamaseUtilDirectory;
                    $file_name = "chirps_daily_".$daily.".mpr";
                    if(!file_exists($directory.DIRECTORY_SEPARATOR.$file_name)){
                        try {
                            exec($command);
                        } catch (Exception $e) {}
                    }
                    if(file_exists($directory.DIRECTORY_SEPARATOR.$file_name)){
                        array_push($mapList, $directory.DIRECTORY_SEPARATOR.$file_name);
                    }
                }
                foreach ($pentads as $pentad) {
                    $batch_file_path = BATCH_DIR.DIRECTORY_SEPARATOR.'Chirps_PENTAD_MAMASE.bat ';
                    $command = ILWIS_DIR.DIRECTORY_SEPARATOR."ilwis.exe -C !".$batch_file_path.$pentad." x  x  ".$this->outputDirectory.DIRECTORY_SEPARATOR."Model_data".DIRECTORY_SEPARATOR."Rainfall_data".' ' .$this->gdalBinDirectory.' ' .$this->mamaseUtilDirectory;
                    $file_name = "chirps_pentad_".$pentad.".mpr";
                    if(!file_exists($directory.DIRECTORY_SEPARATOR.$file_name)){
                        try {
                            exec($command);
                        } catch (Exception $e) {}
                    }
                    if(file_exists($directory.DIRECTORY_SEPARATOR.$file_name)){
                        array_push($mapList, $directory.DIRECTORY_SEPARATOR.$file_name);
                    }
                }
                foreach ($dekads as $dekad) {
                    $batch_file_path = BATCH_DIR.DIRECTORY_SEPARATOR.'Chirps_DEKAD_MAMASE.bat ';
                    $command = ILWIS_DIR.DIRECTORY_SEPARATOR."ilwis.exe -C !".$batch_file_path.$dekad." x  x  ".$this->outputDirectory.DIRECTORY_SEPARATOR."Model_data".DIRECTORY_SEPARATOR."Rainfall_data".' ' .$this->gdalBinDirectory.' ' .$this->mamaseUtilDirectory;
                    $file_name = "chirps_dekad_".$dekad.".mpr";
                    if(!file_exists($directory.DIRECTORY_SEPARATOR.$file_name)){
                        try {
                            exec($command);
                        } catch (Exception $e) {}
                    }
                    if(file_exists($directory.DIRECTORY_SEPARATOR.$file_name)){
                        array_push($mapList, $directory.DIRECTORY_SEPARATOR.$file_name);
                    }
                }
                $list = '"'.implode(" ",$mapList).'"';
                $batch_file_path = BATCH_DIR.DIRECTORY_SEPARATOR.'Chirps16Days_Aggregate.bat ';
                $command = ILWIS_DIR.DIRECTORY_SEPARATOR."ilwis.exe -C !".$batch_file_path.$list." ".$this->outputDirectory.DIRECTORY_SEPARATOR."Model_data".DIRECTORY_SEPARATOR."Rainfall_data".' '.ILWIS_DIR.' ' .$this->gdalBinDirectory.' ' .$data[$x];
                try {
                    exec($command);
                } catch (Exception $e) {}
                $data = array();
                $mapList = array();
                $dailies = array();
                $pentads = array();
                $dekads = array();
            }
        }
    }
    public function generate16DaysBiomassMaps($startDate, $endDate){
        $directory = $this->working_dir.DIRECTORY_SEPARATOR."Model_data".DIRECTORY_SEPARATOR."Biomass_data";
        if(!file_exists($directory)){
            mkdir($directory);
        }
        $startYear = $startDate->format('Y');
        $endYear = $endDate->format('Y');
        for($year = $startYear; $year < $endYear; $year++){
            $date = "";
            $datetime = new DateTime($year.'-01-01');
            for($i = 1; $i <=23; $i++){
                $date = $datetime->format('Y').$datetime->format('m').$datetime->format('d');
                $batch_file_path = BATCH_DIR.DIRECTORY_SEPARATOR.'Biomass_calc.bat ';
                $command = ILWIS_DIR.DIRECTORY_SEPARATOR.'ilwis.exe -C !'.$batch_file_path.$date.' '.$this->outputDirectory.DIRECTORY_SEPARATOR."Model_data".DIRECTORY_SEPARATOR."Rainfall_data".' '.$this->outputDirectory.DIRECTORY_SEPARATOR."Model_data".DIRECTORY_SEPARATOR."Biomass_data".' '.ILWIS_DIR;
                $new_file = $this->working_dir.DIRECTORY_SEPARATOR."Model_data".DIRECTORY_SEPARATOR."Biomass_data"."\biomass_".$date.".tif";
                if(!file_exists($new_file) && file_exists($this->working_dir.DIRECTORY_SEPARATOR."Model_data".DIRECTORY_SEPARATOR."Rainfall_data".DIRECTORY_SEPARATOR."rainfall_map_".$date.".mpr")){
                    try {
                        exec($command);
                    } catch (Exception $e) {

                    }
                }
                date_add($datetime,date_interval_create_from_date_string("16 days"));
                $datetime = date_format($datetime,"Y-m-d");
                $datetime = date_create_from_format("Y-m-d", $datetime);
            }
        }
        /**
        *Publish raster data to geoserver
        */
        $style = "demand_style";
        $workspace = 'Model_Biomass';
        $dataFolderPath = $this->working_dir.DIRECTORY_SEPARATOR."Model_data".DIRECTORY_SEPARATOR."Biomass_data";
        $this->GeoServer->publishRasterMaps($workspace, $style, $dataFolderPath, 'Yes');
        /**
        *Insert the name of the biomass maps to the database
        */
        $this->DB_Models->updateTable("biomass", $dataFolderPath);
    }
    public  function generateDemandMaps(){
        /**
         *Publish raster data to geoserver
         */
        $style = "demand_style";
        $workspace = 'Model_Biomass';
        $dataFolderPath = $this->working_dir.DIRECTORY_SEPARATOR."Model_data".DIRECTORY_SEPARATOR."Demand_data";
        $this->GeoServer->publishRasterMaps($workspace, $style, $dataFolderPath, 'Yes');
    }
    public function generateRainfallCons($startDate, $endDate){
        $startYear = $startDate->format('Y');
        $endYear = $endDate->format('Y');
        for($year = $startYear; $year < $endYear; $year++) {
            $date = "";
            $datetime = new DateTime($year . '-01-01');
            for ($i = 1; $i <= 23; $i++) {
                $date = $datetime->format('Y') . $datetime->format('m') . $datetime->format('d');
                $batch_file_path = BATCH_DIR.DIRECTORY_SEPARATOR.'Rainfall_Cons.bat ';
                $command = ILWIS_DIR.DIRECTORY_SEPARATOR.'ilwis.exe -C !'.$batch_file_path.$date.' '.$this->outputDirectory.DIRECTORY_SEPARATOR."Model_data".DIRECTORY_SEPARATOR."Rainfall_data".' '.$this->outputDirectory.DIRECTORY_SEPARATOR."Model_data".DIRECTORY_SEPARATOR."Rainfall_data".DIRECTORY_SEPARATOR."Rainfall_Conservancy".' '.ILWIS_DIR;
                $new_file = $this->working_dir.DIRECTORY_SEPARATOR."Model_data".DIRECTORY_SEPARATOR."Rainfall_data".DIRECTORY_SEPARATOR."Rainfall_Conservancy"."\rainfall_cons250m_".$date.".mpr";
                if(file_exists($this->working_dir.DIRECTORY_SEPARATOR."Model_data".DIRECTORY_SEPARATOR."Rainfall_data".DIRECTORY_SEPARATOR."rainfall_map_".$date.".mpr")){
                    if(!file_exists($new_file)){
                        try {
                            exec($command);
                        } catch (Exception $e) {

                        }
                    }
                }
                date_add($datetime,date_interval_create_from_date_string("16 days"));
                $datetime = date_format($datetime,"Y-m-d");
                $datetime = date_create_from_format("Y-m-d", $datetime);
            }
        }
    }
}

?>