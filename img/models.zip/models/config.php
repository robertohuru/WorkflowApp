<?php

define('ROOT_DIRECTORY', "C:".DIRECTORY_SEPARATOR."Apache24".DIRECTORY_SEPARATOR."htdocs".DIRECTORY_SEPARATOR."MARIS");

$configpath = "config.json";

$string = file_get_contents(ROOT_DIRECTORY.DIRECTORY_SEPARATOR.$configpath);
$json = json_decode($string, true);

/**
 * Database configuration variables
 */


define("DB_HOST", $json['database'][0]['host']);
define("DB_USER", $json['database'][0]['user'] );
define("DB_PASSWORD", $json['database'][0]['password'] );
define("DB_PORT", $json['database'][0]['port']);
define("DB_DATABASE", $json['database'][0]['name'] );

//Geoserver Configuration

/**
*/
define("GEO_HOST", $json['geoserver'][0]['host']);
define("GEO_USER", $json['geoserver'][0]['user']);
define("GEO_PASSWORD", $json['geoserver'][0]['password']);
define("GEO_PORT", $json['geoserver'][0]['port']);

//Email Configuration

/**
*/
define("EMAIL_HOST",$json['email'][0]['host']);
define("USERNAME",$json['email'][0]['username']);
define("PASSWORD",$json['email'][0]['password']);
define("FROM_ADDRESS", $json['email'][0]['fromAddress']);
define("FROM_NAME",$json['email'][0]['fromName']);
define("SMTPAuth",$json['email'][0]['SMTPAuth']);

/*
*Data folders
*/
define("JAVA_DIR",$json['folders'][0]['java']);
define("ILWIS_DIR",$json['folders'][0]['ilwis']);
define("MAMASE_UTIL",$json['folders'][0]['mamaseUtil']);
define("GDAL_UTIL", $json['folders'][0]['gdalUtil']);
define("WORKING_DIR",$json['folders'][0]['working_dir']);
define("WORKING_DISK",$json['folders'][0]['working_disk']);
define("BATCH_DIR",$json['folders'][0]['batch_routines']);
define("SCRIPTS_DIR",$json['folders'][0]['start_scripts']);
define("RAINFALL_OUTPUT_DIR",$json['folders'][0]['rainfall_dir']);
define("NDVI_DIR",$json['folders'][0]['NDVI_dir']);
define("DEMAND_DIR",$json['folders'][0]['demand_dir']);
define("STYLES_DIR",$json['folders'][0]['styles_dir']);
define("TOOLBOX_DIR",$json['folders'][0]['mamase_toolbox']);


?>