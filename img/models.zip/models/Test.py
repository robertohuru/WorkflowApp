import ilwis, sys
ilwis.Engine.setWorkingCatalog("file:///G:/working_dir/Model_data/Rainfall_data");
raster=ilwis.RasterCoverage("rainfall_map_20070101.mpr")
#print (raster.coord2value(ilwis.Coordinate (735736.07, 9833232.04)))
print (raster.coord2value(ilwis.Coordinate (float(sys.argv[1]), float(sys.argv[2]))))

