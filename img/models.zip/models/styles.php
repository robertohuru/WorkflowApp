<?php
/*
This file publish the already set styles to geoserver
The styles are in sld file in the folder specified in the config.json file
*/

require_once 'config.php';
$configFile = "config.json";
$configFilePath = ROOT_DIRECTORY.DIRECTORY_SEPARATOR.$configFile;
$configFilePath = str_replace("/",DIRECTORY_SEPARATOR,$configFilePath);

$stylesFolder = STYLES_DIR;
if(!file_exists($stylesFolder))
	die("Styles folder does not exist");

$jarFilePath = JAVA_DIR.DIRECTORY_SEPARATOR.'GeoJava.jar';
$workspace = "Styles";
$style = "raster";
$projection = "EPSG:21036";
$command = 'java -jar '.$jarFilePath.' '.$workspace.' '.$stylesFolder.' '.$style.' '.$projection.' '.$configFilePath.' Yes'.' Style';
try {
	exec($command);
}catch (Exception $e) {

}
?>