<?php
$data = json_decode(file_get_contents("php://input"));

$filename = $data->filename;
$filetype = $data->filetype;

if($filetype == 'shapefile'){
    $filename = $filename.'.zip';
}else{
    $filename = $filename.'.tif';
}

$path = "./files/"; // change the path to fit your websites document structure
$fullPath = $path.$filename;
echo $fullPath;
/*
if(file_exists(realpath($fullPath))){
    echo $fullPath;
}else{
    echo 0;
}*/
?>