<?php
/*
This php file queries the database for the names of live or rainfall/NDVI/biomass maps and
then send the names to the webclient so that the corresponding maps are fetched from the geoserver and their information displayed on the webclient
*/
$input = json_decode(file_get_contents("php://input"));
require_once 'DB_functions.php';
$type = $input->type;
//$type = "rainfall";
$DB_Functions = new DB_Functions();
if($type == "rainfall"){
	$data = $DB_Functions->getRainfallData();
	echo json_encode($data);
}else if($type == "ndvi"){
	$data = $DB_Functions->getNDVIdata();
	echo json_encode($data);
}else if($type == "biomass"){
    $data = $DB_Functions->getModelsData();
    echo json_encode($data);
}




?>