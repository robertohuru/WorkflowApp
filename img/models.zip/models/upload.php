<?php

$name = $_POST['name'];
$array = explode(' ', $name);
$name = $array[0].'_'.$array[1];

$ROOT = "C:\Apache24\htdocs\MARIS\app";
$target_dir = $ROOT."\WorkSpaces".DIRECTORY_SEPARATOR.$name."\Inputs".DIRECTORY_SEPARATOR;
$name = $_POST['name'];
include 'GeoClass.php';


//$jsonString = file_get_contents('../WorkSpaces/workflow.json');
//$data = json_decode($jsonString, true);

//$geo = new GeoClass();

$nameArr = explode(' ',$name);
//$workspace = $nameArr[0].'_'.$nameArr[1];
//$geo->createWorkSpace($workspace);
//$datasource= "boundary";
//$layername = $path = "";
$logfh = fopen("GeoserverPHP.log", 'w') or die("can't open log file");
//$target_file = $target_dir . basename($_FILES["file"]["name"]);
$destName = $_POST['filename'];
$file_name = $_FILES['file']['name'];
$file_size = $_FILES['file']['size'];
$file_tmp = $_FILES['file']['tmp_name'];
$file_type = $_FILES['file']['type'];
realpath($file_tmp);
if (empty($errors) == true) {
    $ext = pathinfo($file_name, PATHINFO_EXTENSION);
    $file_name = $destName.'.'.$ext;
    $dfile = $target_dir. $file_name;
    if (move_uploaded_file($file_tmp, $dfile)) {
        if($ext == "zip"){
            $file = $dfile;
            // get the absolute path to $file
            $path = pathinfo(realpath($file), PATHINFO_DIRNAME);
            $nameArr = explode('.',$file_name);
            $name = $nameArr[0];
            $type = $nameArr[1];
            $path = $path.DIRECTORY_SEPARATOR.$name.DIRECTORY_SEPARATOR;
            if(!file_exists($path)){
                mkdir($path);
            }          
            $zip = new ZipArchive;
            $res = $zip->open($file);
            if ($res === TRUE) {
                // extract it to the path we determined above
                $zip->extractTo($path);
                $zip->close();
            }           
            $files = scandir($path);
            foreach($files as $file)
            { 
                $nameArr = explode('.',$file);
                $type = $nameArr[1];                
                if ($type == "shp") {
                    $path = realpath($path.$file);
                    $path = str_replace("\\", '/', $path);
                    $path = "file:///" . $path;
                    $array = explode('.shp',$file);                    
                    //$layername = $array[0];
                }else{

                }
                    
            }
            //unlink($dfile);
            //$geo->addLayer($workspace, $datasource, $path);
        }
        //fwrite($logfh, $jsonString);
        echo 1;
    }else{
        echo 0;
        fwrite($logfh, "Failed to upload");
    }
}else {
    echo "Failed to Upload";
    fwrite($logfh, $errors);
}
fwrite($logfh, $_FILES['file']['size']);
fclose($logfh);
?>