<?php
require_once 'config.php';
$configFile = "config.json";
$configFilePath = ROOT_DIRECTORY.DIRECTORY_SEPARATOR.$configFile;
$configFilePath = str_replace("/",DIRECTORY_SEPARATOR,$configFilePath);

$workspace = "NDVI_pre_process";
$defaultPath = DEMAND_DIR.DIRECTORY_SEPARATOR.$workspace;
$outputDirectory = WORKING_DISK." working_dir".DIRECTORY_SEPARATOR."NDVI_data".DIRECTORY_SEPARATOR.$workspace;
$gdalBinDirectory = GDAL_UTIL;
$mamaseUtilDirectory = ILWIS_DIR.' '.MAMASE_UTIL;

$batch_file_path = BATCH_DIR.'\FTP.bat ';
$ftpUrl = "ftp://130.89.221.193:120/NDVI_data/NDVI_pre_process";

$startYear = 2001;
$endYear = 2016;
$doy = "";
for($year = $startYear; $year < $endYear; $year++){
    for($i = 1; $i <=353; $i+=16){
        if($i < 10){
            $doy = $year.'00'.$i;
        }else if($i > 9 && $i < 100){
            $doy = $year.'0'.$i;
        }else if($i > 99){
            $doy = $year.$i;
        }
        $name = "A".$doy.".hdf";
        $command = 'Ilwis.exe -C !'.$batch_file_path.$name.' x  x  '.$outputDirectory.' '.$gdalBinDirectory.' '.$mamaseUtilDirectory.' '.$ftpUrl;              
        try {
            exec($command);            
        }
        catch (Exception $e) {
        }
    }
}


?>