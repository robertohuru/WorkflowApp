<?php

/*$data = array("account" => "1234", "dob" => "30051987", "site" => "mytestsite.com");
$data_string = json_encode($data);
$url = "http://127.0.0.1:8081";
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json','Content-Length: ' . strlen($data_string)));
$result = curl_exec($ch);
curl_close($ch);
echo $result;*/

$year = '2017';
$k = '10';
$dekad = '3';
$url = "https://tamsat.org.uk/public_data/".$year."/".$k."/rfe".$year."_".$k."-dk".$dekad.".nc";

stream_context_set_default( [
    'ssl' => [
        'verify_peer' => false,
        'verify_peer_name' => false,
    ],
]);
//$url = "https://tamsat.org.uk/public_data/2017/09/rfe2017_09-dk3.nc";
$headers = get_headers($url,1);
$ret = substr($headers[0], 9, 3);
if($ret >= 200 && $ret < 400){
    echo "Available";
}else{
    echo "Not Available";
}
?>